# 心情树洞 桌面客户端（Windows / Mac）

用 Electron 封装。**同一份代码**同时打包成 Windows 和 Mac 应用，只有打包目标不同。

## 它是怎么工作的

- 应用启动后加载一个**本地壳页面**（`shell.html`），壳里用 `webview` 嵌入你服务器的网站。
- 因为壳是本地的「安全上下文」，所以**麦克风（语音输入）即使服务器是 http 也能用** —— 这正是桌面版比浏览器直接访问强的地方。
- 功能完全等于网站本身（日历、推荐、AI 树洞、语音、登录、管理后台），而且**永远和网站同步**，你改服务器就行，不用重新发版。
- 语音输出（edge-tts）本来就不受 http 限制，照常可用。

## 改服务器地址

打开 `config.json`，把地址改成你的：
```json
{ "serverUrl": "http://sc1.dpfrp.top:12345" }
```
打包后这个文件在安装目录里也能改（改完重启应用生效）。

## 在本机运行（开发 / 测试）

需要 **Node.js 18+**（https://nodejs.org）。在本文件夹开终端：
```bash
npm install
npm start
```

## 打包成安装包

> 在哪个系统上就能打哪个系统的包：**Windows 的 .exe 要在 Windows 上打，Mac 的 .dmg 要在 Mac 上打**（这是 Electron 的限制，跨系统打包很麻烦，别折腾）。

Windows（生成 `dist/心情树洞 Setup x.x.x.exe` 安装版 + 免安装 portable）：
```bash
npm run dist:win
```

Mac（生成 `dist/心情树洞-x.x.x.dmg`）：
```bash
npm run dist:mac
```

产物都在 `dist/` 目录里。

## 图标（可选）

把图标放进 `build/`（见 `build/README-icons.txt`）：
- `icon.ico`（Windows）、`icon.icns`（Mac）。
- 不放也能打包，会用 Electron 默认图标；或删掉 `package.json` 里的 `icon` 字段。

## 安卓端

安卓我会单独做（用 Capacitor / WebView 壳，思路一样：本地壳解锁麦克风 + 加载你的服务器）。告诉我就开工。

## 备注

- 这是「轻壳」方案：UI 从服务器实时加载，所以**离线时打不开**（需要能连到你的服务器）。
- 外部链接（B站、tel: 拨号等）会用系统默认程序打开，不在应用里乱跳。
