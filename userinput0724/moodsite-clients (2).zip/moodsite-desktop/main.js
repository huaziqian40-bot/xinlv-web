// 心情树洞 桌面客户端（Electron）
// 思路：本地壳页面控制"安全上下文"，从而解锁麦克风（即便服务器是 http）；
// 真正的功能页面从你的服务器加载，永远和网站同步。
// Windows / Mac 用同一份代码，只有打包目标不同（见 package.json 的 build 配置）。

const { app, BrowserWindow, session, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs');

// 读取服务器地址：优先用打包时写入的 config.json，其次默认值。
function loadServerUrl() {
  try {
    const cfgPath = path.join(__dirname, 'config.json');
    const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf-8'));
    if (cfg.serverUrl) return cfg.serverUrl.replace(/\/+$/, '');
  } catch (e) {}
  return 'http://sc1.dpfrp.top:12345'; // 默认：你的穿透地址，可在 config.json 改
}

const SERVER_URL = loadServerUrl();
let win;

function createWindow() {
  win = new BrowserWindow({
    width: 980,
    height: 760,
    minWidth: 360,
    minHeight: 520,
    title: '心情树洞',
    icon: path.join(__dirname, 'build', process.platform === 'darwin' ? 'icon.icns' : 'icon.ico'),
    backgroundColor: '#f5f3ef',
    webPreferences: {
      // 安全壳：不暴露 node 给远端页面
      nodeIntegration: false,
      contextIsolation: true,
      // 关键：开启 webview 标签（新版 Electron 默认关闭，不开会白屏）
      webviewTag: true,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  // 自动允许麦克风权限请求（用于 AI 树洞语音输入）
  session.defaultSession.setPermissionRequestHandler((wc, permission, callback) => {
    const allowed = ['media', 'microphone', 'audioCapture'];
    callback(allowed.includes(permission));
  });
  session.defaultSession.setPermissionCheckHandler((wc, permission) => {
    return ['media', 'microphone', 'audioCapture'].includes(permission);
  });

  // 先加载本地壳（决定安全上下文），由壳页面把功能页嵌进来
  win.loadFile(path.join(__dirname, 'shell.html'));

  // 外部链接（如 B站、求助热线 tel:）用系统默认程序打开，不在 app 里乱跳
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith(SERVER_URL)) return { action: 'allow' };
    shell.openExternal(url);
    return { action: 'deny' };
  });

  win.webContents.on('will-navigate', (e, url) => {
    // 顶层窗口本身不允许导航走，导航发生在内嵌 webview 里
    if (!url.startsWith('file://')) {
      e.preventDefault();
    }
  });
}

// 把服务器地址传给壳页面
const { ipcMain } = require('electron');
ipcMain.handle('get-server-url', () => SERVER_URL);

app.whenReady().then(() => {
  buildMenu();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

function buildMenu() {
  const isMac = process.platform === 'darwin';
  const template = [
    ...(isMac ? [{ role: 'appMenu' }] : []),
    {
      label: '操作',
      submenu: [
        { label: '刷新', accelerator: 'CmdOrCtrl+R', click: () => win && win.reload() },
        { label: '后退', accelerator: 'CmdOrCtrl+Left', click: () => win && win.webContents.send('nav', 'back') },
        { type: 'separator' },
        isMac ? { role: 'close', label: '关闭' } : { role: 'quit', label: '退出' },
      ],
    },
    { role: 'editMenu', label: '编辑' },
    {
      label: '视图',
      submenu: [
        { role: 'resetZoom', label: '实际大小' },
        { role: 'zoomIn', label: '放大' },
        { role: 'zoomOut', label: '缩小' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: '全屏' },
        { role: 'toggleDevTools', label: '开发者工具' },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}
