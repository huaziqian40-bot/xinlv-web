@echo off
cd /d %~dp0
echo Installing dependencies (first time, needs internet)...
call npm install
echo.
echo Done. Next:
echo   - Run test.bat to preview
echo   - Run build-windows.bat to make the exe
pause
