// 安全桥：只把"获取服务器地址""菜单导航事件"暴露给壳页面，不暴露 node。
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('moodApp', {
  getServerUrl: () => ipcRenderer.invoke('get-server-url'),
  onNav: (cb) => ipcRenderer.on('nav', (_e, dir) => cb(dir)),
});
