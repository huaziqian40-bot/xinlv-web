@echo off
cd /d %~dp0
echo Building Windows installer...
call npm run dist:win
echo.
echo Done. Installers are in the dist folder:
echo   - "...Setup 1.0.0.exe"  (installer)
echo   - "...1.0.0.exe"        (portable, double-click to run)
pause
