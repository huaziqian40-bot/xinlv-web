// Capacitor 配置：安卓壳。
// 思路与桌面端一致——本地壳页面是安全上下文，加载你服务器的网站，
// 因此麦克风（语音输入）即使服务器是 http 也能用。
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.huaziqian.moodsite',
  appName: '心情树洞',
  webDir: 'www',
  server: {
    // 允许从本地壳跳转到你的服务器域名
    allowNavigation: ['sc1.dpfrp.top'],
    // 安卓 9+ 默认禁止 http 明文，这里允许（因为你的服务器是 http）
    cleartext: true,
  },
  android: {
    allowMixedContent: true,
  },
};

export default config;
