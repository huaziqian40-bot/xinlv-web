@echo off
cd /d %~dp0
echo Syncing and building APK (debug, installable)...
call npx cap sync android
cd android
call gradlew.bat assembleDebug
echo.
echo ============================================
echo   Done. APK is here:
echo   android\app\build\outputs\apk\debug\app-debug.apk
echo   Send it to your phone and install (allow "unknown sources").
echo ============================================
pause
