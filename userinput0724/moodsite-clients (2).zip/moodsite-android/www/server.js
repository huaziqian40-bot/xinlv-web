// 服务器地址。改这里即可（改完需重新 npx cap sync 再打包）。
window.MOOD_SERVER_URL = "http://sc1.dpfrp.top:12345";
