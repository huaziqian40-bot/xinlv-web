@echo off
cd /d %~dp0
echo ============================================
echo   MoodSite Android - first-time setup
echo ============================================
echo.
echo [1/3] Installing dependencies...
call npm install
echo.
echo [2/3] Creating android native project...
call npx cap add android
echo.
echo [3/3] Syncing web content...
call npx cap sync android
echo.
echo ============================================
echo   Done. Next:
echo   - Add mic permission: see guide section "android" (IMPORTANT)
echo   - Build apk: run build-apk.bat
echo ============================================
pause
