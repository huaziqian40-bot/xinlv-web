@echo off
chcp 65001 >nul
cd /d %~dp0
echo 正在打包 Windows 安装程序...
call npm run dist:win
echo.
echo ============================================
echo   完成！安装包在 dist 文件夹里：
echo   - 心情树洞 Setup x.x.x.exe   （安装版）
echo   - 心情树洞 x.x.x.exe          （免安装版，直接双击就能用）
echo ============================================
pause
