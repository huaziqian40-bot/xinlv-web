@echo off
chcp 65001 >nul
cd /d %~dp0
echo 正在安装依赖（只需第一次运行，需要联网）...
call npm install
echo.
echo 完成！接下来可以：
echo   - 双击 测试运行.bat 先看效果
echo   - 双击 打包Windows.bat 生成 exe
pause
