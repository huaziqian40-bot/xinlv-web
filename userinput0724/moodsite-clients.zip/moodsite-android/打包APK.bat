@echo off
chcp 65001 >nul
cd /d %~dp0
echo 正在同步并打包 APK（debug 版，可直接安装）...
call npx cap sync android
cd android
call gradlew.bat assembleDebug
echo.
echo ============================================
echo   完成！APK 在这里：
echo   android\app\build\outputs\apk\debug\app-debug.apk
echo   把它发到手机上安装即可（需允许"未知来源"）。
echo ============================================
pause
