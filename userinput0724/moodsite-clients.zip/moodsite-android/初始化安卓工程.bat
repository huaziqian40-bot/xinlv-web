@echo off
chcp 65001 >nul
cd /d %~dp0
echo ============================================
echo   心情树洞 安卓工程初始化（只需第一次运行）
echo ============================================
echo.
echo [1/3] 安装依赖...
call npm install
echo.
echo [2/3] 生成安卓原生工程...
call npx cap add android
echo.
echo [3/3] 同步网页内容到安卓工程...
call npx cap sync android
echo.
echo ============================================
echo   完成！接下来：
echo   - 录音权限补丁：见 README「安卓」一节（重要！否则语音输入不可用）
echo   - 打包 apk：双击 打包APK.bat
echo ============================================
pause
