# 心情树洞 · Mood Calendar + AI 电子树洞

一个用 Django 写的网站：记录每天心情的日历，根据心情推送舒缓方式（本地歌曲、行为建议、即时小练习），正面心情则推送心理学小知识；内置一个用 DeepSeek API 驱动的"AI 电子树洞"陪你聊天。适合作为 B 站 ASMR / 心理学内容的引流落地页。

---

## 一、本地跑起来（先在自己电脑上验证）

需要 **Python 3.10+**。在项目根目录（有 `manage.py` 的地方）打开命令行：

```bat
:: 1. 建虚拟环境（推荐）
python -m venv venv
venv\Scripts\activate

:: 2. 装依赖
pip install -r requirements.txt

:: 3. 准备配置：复制 .env.example 为 .env，填上 DeepSeek 的 API Key
copy .env.example .env
notepad .env

:: 4. 初始化数据库
python manage.py migrate

:: 5. 填充示例数据（舒缓行为 + 心理学小知识）
python manage.py seed_data

:: 6. 建后台管理员账号（用来在 /admin/ 管内容）
python manage.py createsuperuser

:: 7. 启动
python manage.py runserver
```

浏览器打开 http://127.0.0.1:8000 ，后台是 http://127.0.0.1:8000/admin/ 。

---

## 二、加音乐（本地文件）

1. 把音频（mp3/m4a/flac/ogg/wav）放进 `media/music/` 目录。
   - 文件名建议写成 `歌手 - 歌名.mp3`，导入时会自动拆分。
2. 运行导入命令：
   ```bat
   python manage.py scan_music
   :: 也可以给这批歌打默认心情标签：
   python manage.py scan_music --moods anxious,sad,tired
   ```
3. 进 `/admin/` → Songs，给每首歌设置适用的心情（`moods` 字段填心情 key，逗号分隔）。
   - 心情 key：happy / calm / excited / grateful / tired / anxious / sad / angry / lonely / numb
   - 留空表示对所有心情都可推荐。

> 推荐逻辑：任何心情都会推歌；负面/中性心情额外给"舒缓行为 + 即时练习"，正面心情给"心理学小知识"。规则在 `core/recommendations.py`，可自行调整。

---

## 三、用 Windows PC 做服务器 + 内网穿透

`runserver` 只适合开发。对外正式提供服务用自带的 **waitress**（已在依赖里）：

1. 改 `.env`：
   - `DJANGO_DEBUG=False`
   - `DJANGO_SECRET_KEY` 换成随机长串
   - `DJANGO_ALLOWED_HOSTS` 填你的公网域名/IP，例如 `mood.example.com`
   - `CSRF_TRUSTED_ORIGINS` 填带协议的完整地址，例如 `https://mood.example.com`
     （**很关键**：不填的话，通过公网域名记录心情/发消息会报 CSRF 403）
2. 收集静态文件：
   ```bat
   python manage.py collectstatic
   ```
   > 注意：`DEBUG=False` 时 Django 默认不再托管 `static/` 和 `media/`。
   > 简单方案：把内网穿透指向 waitress，并用下面的 whitenoise 方案托管静态文件；
   > 媒体音乐文件可让穿透/反代直接指向 `media/` 目录，或保持 DEBUG=True 仅在可信网络使用。
3. 启动（或双击 `run_server.bat`）：
   ```bat
   python -m waitress --listen=0.0.0.0:8000 moodsite.wsgi:application
   ```
4. 把你的**内网穿透**工具（frp / cpolar / 花生壳 / cloudflared 等）的目标指向本机 `127.0.0.1:8000`，
   公网端口/域名映射到这里即可。

### 关于 DEBUG=False 下的静态文件（最省事的做法）
装 whitenoise，让 waitress 自己托管 CSS：
```bat
pip install whitenoise
```
然后在 `moodsite/settings.py` 的 MIDDLEWARE 中，`SecurityMiddleware` 之后加一行：
```python
"whitenoise.middleware.WhiteNoiseMiddleware",
```
再加：
```python
STORAGES = {"staticfiles": {"BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage"}}
```
媒体音乐文件仍建议由穿透工具/反向代理直接指向 `media/` 目录提供。

---

## 四、AI 树洞配置

- 去 https://platform.deepseek.com 申请 API Key，填进 `.env` 的 `DEEPSEEK_API_KEY`。
- 模型默认 `deepseek-v4-flash`（便宜、快，适合聊天）。人设和安全规则在 `core/deepseek.py` 的 `SYSTEM_PROMPT`，可自行调整语气。
- 树洞会自动带上最近 20 条上下文（DeepSeek 接口无状态，需自己拼历史）。

> ⚠️ 这是一个面向陌生人情绪的产品，请务必保留并完善危机引导：当有人流露伤害自己的念头时，
> 引导其联系信任的人或专业心理援助热线，不要让 AI 给出任何危险建议。页脚已放了热线提示，
> **请核实当地最新的心理援助热线号码后再上线**。

---

## 五、目录结构

```
moodsite/
├── manage.py
├── .env.example          # 配置模板
├── requirements.txt
├── run_server.bat        # Windows 一键启动
├── moodsite/             # 项目配置
│   ├── settings.py
│   └── urls.py
├── core/                 # 主应用
│   ├── models.py         # 心情/歌曲/行为/小知识/聊天 数据模型
│   ├── views.py          # 日历、记录、推荐、树洞
│   ├── recommendations.py# 心情→推荐 逻辑
│   ├── deepseek.py       # DeepSeek 客户端 + 树洞人设
│   └── management/commands/
│       ├── scan_music.py # 导入本地音乐
│       └── seed_data.py  # 填充示例内容
├── templates/            # 页面
├── static/css/style.css  # 样式
└── media/music/          # 你的本地音乐放这里
```

## 六、隐私说明
访客用浏览器 session 区分，**不需要注册**。心情记录和聊天记录按 session 存在本地 SQLite。
如果以后要做"长期保存/换设备同步"，再加上 Django 的用户登录即可。
