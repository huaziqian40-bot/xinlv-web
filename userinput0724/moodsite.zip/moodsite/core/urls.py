from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("save/", views.save_mood, name="save_mood"),
    path("result/", views.result, name="result"),
    path("confidant/", views.confidant, name="confidant"),
    path("confidant/send/", views.confidant_send, name="confidant_send"),
    path("confidant/clear/", views.confidant_clear, name="confidant_clear"),
]
