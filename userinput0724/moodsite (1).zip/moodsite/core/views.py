import calendar
import datetime as dt
import json

from django.conf import settings
from django.http import JsonResponse, HttpResponseBadRequest
from django.shortcuts import render, redirect
from django.views.decorators.http import require_POST

from .models import MoodEntry, ChatMessage, MOODS, MOOD_MAP, MOOD_KEYS
from . import recommendations, deepseek


def _sid(request):
    """确保有 session_key 用来区分访客。"""
    if not request.session.session_key:
        request.session.create()
    return request.session.session_key


def home(request):
    """带月历的首页。?y=2026&m=6 切换月份。"""
    sid = _sid(request)
    today = dt.date.today()
    try:
        year = int(request.GET.get("y", today.year))
        month = int(request.GET.get("m", today.month))
        dt.date(year, month, 1)
    except (ValueError, TypeError):
        year, month = today.year, today.month

    # 本月已记录的心情
    entries = {
        e.date.day: e
        for e in MoodEntry.objects.filter(session_key=sid, date__year=year, date__month=month)
    }

    cal = calendar.Calendar(firstweekday=0)  # 周一开头
    weeks = []
    for week in cal.monthdayscalendar(year, month):
        row = []
        for day in week:
            cell = {"day": day, "entry": None, "is_today": False, "in_future": False}
            if day:
                d = dt.date(year, month, day)
                cell["entry"] = entries.get(day)
                cell["is_today"] = (d == today)
                cell["in_future"] = (d > today)
            row.append(cell)
        weeks.append(row)

    prev_m = (dt.date(year, month, 1) - dt.timedelta(days=1))
    next_first = (dt.date(year, month, 28) + dt.timedelta(days=10)).replace(day=1)

    ctx = {
        "year": year, "month": month,
        "month_name": f"{year}年{month}月",
        "weeks": weeks,
        "weekday_labels": ["一", "二", "三", "四", "五", "六", "日"],
        "moods": MOODS,
        "prev": {"y": prev_m.year, "m": prev_m.month},
        "next": {"y": next_first.year, "m": next_first.month},
        "today_iso": today.isoformat(),
        "recent": MoodEntry.objects.filter(session_key=sid)[:7],
    }
    return render(request, "home.html", ctx)


@require_POST
def save_mood(request):
    """记录/更新某天心情，然后跳到推荐页。"""
    sid = _sid(request)
    date_str = request.POST.get("date", "")
    mood = request.POST.get("mood", "")
    note = request.POST.get("note", "").strip()
    try:
        date = dt.date.fromisoformat(date_str)
    except ValueError:
        return HttpResponseBadRequest("日期格式错误")
    if mood not in MOOD_KEYS:
        return HttpResponseBadRequest("未知心情")
    if date > dt.date.today():
        return HttpResponseBadRequest("不能记录未来的日期")

    MoodEntry.objects.update_or_create(
        session_key=sid, date=date,
        defaults={"mood": mood, "note": note},
    )
    return redirect(f"/result/?date={date_str}")


def result(request):
    """根据当天心情展示推荐。"""
    sid = _sid(request)
    date_str = request.GET.get("date", dt.date.today().isoformat())
    try:
        date = dt.date.fromisoformat(date_str)
    except ValueError:
        date = dt.date.today()
    entry = MoodEntry.objects.filter(session_key=sid, date=date).first()
    if not entry:
        return redirect("/")
    rec = recommendations.build(entry.mood)
    return render(request, "result.html", {"entry": entry, "rec": rec})


# ---------- AI 树洞 ----------
def confidant(request):
    sid = _sid(request)
    history = ChatMessage.objects.filter(session_key=sid)
    return render(request, "confidant.html", {"history": history})


@require_POST
def confidant_send(request):
    sid = _sid(request)
    try:
        text = json.loads(request.body).get("message", "").strip()
    except (json.JSONDecodeError, AttributeError):
        text = request.POST.get("message", "").strip()
    if not text:
        return JsonResponse({"error": "空消息"}, status=400)

    ChatMessage.objects.create(session_key=sid, role="user", content=text)

    # 取最近 20 条作为上下文（DeepSeek 是无状态的，需自己拼历史）
    recent = list(ChatMessage.objects.filter(session_key=sid).order_by("-created_at")[:20])
    recent.reverse()
    history = [{"role": m.role, "content": m.content} for m in recent]

    reply, err = deepseek.chat(history)
    if reply is None:
        reply = err  # 把友好的错误提示直接当作树洞回复显示
    else:
        ChatMessage.objects.create(session_key=sid, role="assistant", content=reply)

    return JsonResponse({"reply": reply})


@require_POST
def confidant_clear(request):
    sid = _sid(request)
    ChatMessage.objects.filter(session_key=sid).delete()
    return JsonResponse({"ok": True})
