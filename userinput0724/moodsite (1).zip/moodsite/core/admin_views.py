"""给"不懂电脑"的站长用的极简管理后台（/manage/）。
比 Django 自带 /admin/ 更友好：中文、按钮大、能直接在浏览器上传音乐。
用 @login_required 保护，账号由站长在部署时用 createsuperuser 创建。
"""
import os

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from .models import Song, Activity, PsychologyTip, MoodEntry, ChatMessage, MOODS

AUDIO_EXT = {".mp3", ".m4a", ".flac", ".ogg", ".wav", ".aac"}


@login_required
def dashboard(request):
    ctx = {
        "n_songs": Song.objects.count(),
        "n_tips": PsychologyTip.objects.count(),
        "n_acts": Activity.objects.count(),
        "n_moods": MoodEntry.objects.count(),
        "n_chats": ChatMessage.objects.filter(role="user").count(),
    }
    return render(request, "manage/dashboard.html", ctx)


@login_required
def songs(request):
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "add":
            f = request.FILES.get("audio")
            if not f:
                messages.error(request, "请先选择一个音频文件。")
            elif os.path.splitext(f.name)[1].lower() not in AUDIO_EXT:
                messages.error(request, "只支持 mp3 / m4a / flac / ogg / wav / aac 格式。")
            else:
                title = request.POST.get("title", "").strip() or os.path.splitext(f.name)[0]
                Song.objects.create(
                    title=title,
                    artist=request.POST.get("artist", "").strip(),
                    audio=f,
                    moods=",".join(request.POST.getlist("moods")),
                )
                messages.success(request, f"已添加歌曲：{title}")
        elif action == "update":
            s = get_object_or_404(Song, pk=request.POST.get("id"))
            s.title = request.POST.get("title", "").strip() or s.title
            s.artist = request.POST.get("artist", "").strip()
            s.moods = ",".join(request.POST.getlist("moods"))
            s.save()
            messages.success(request, f"已更新：{s.title}")
        elif action == "delete":
            s = get_object_or_404(Song, pk=request.POST.get("id"))
            name = s.title
            if s.audio:
                s.audio.delete(save=False)  # 同时删掉硬盘上的文件
            s.delete()
            messages.success(request, f"已删除：{name}")
        return redirect("manage_songs")

    return render(request, "manage/songs.html", {"songs": Song.objects.all(), "moods": MOODS})


@login_required
def tips(request):
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "add":
            title = request.POST.get("title", "").strip()
            content = request.POST.get("content", "").strip()
            if title and content:
                PsychologyTip.objects.create(
                    title=title, content=content,
                    source=request.POST.get("source", "").strip(),
                )
                messages.success(request, "已添加一条小知识。")
            else:
                messages.error(request, "标题和内容都要填哦。")
        elif action == "delete":
            t = get_object_or_404(PsychologyTip, pk=request.POST.get("id"))
            t.delete()
            messages.success(request, "已删除。")
        return redirect("manage_tips")
    return render(request, "manage/tips.html", {"tips": PsychologyTip.objects.all()})


@login_required
def activities(request):
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "add":
            text = request.POST.get("text", "").strip()
            if text:
                Activity.objects.create(
                    text=text, moods=",".join(request.POST.getlist("moods")),
                )
                messages.success(request, "已添加一条建议。")
            else:
                messages.error(request, "请先填写内容。")
        elif action == "delete":
            a = get_object_or_404(Activity, pk=request.POST.get("id"))
            a.delete()
            messages.success(request, "已删除。")
        return redirect("manage_activities")
    return render(request, "manage/activities.html",
                  {"activities": Activity.objects.all(), "moods": MOODS})
