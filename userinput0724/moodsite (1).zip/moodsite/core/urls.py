from django.contrib.auth import views as auth_views
from django.urls import path
from . import views, admin_views

urlpatterns = [
    path("", views.home, name="home"),
    path("save/", views.save_mood, name="save_mood"),
    path("result/", views.result, name="result"),
    path("confidant/", views.confidant, name="confidant"),
    path("confidant/send/", views.confidant_send, name="confidant_send"),
    path("confidant/clear/", views.confidant_clear, name="confidant_clear"),

    # ---- 简易管理后台 ----
    path("manage/login/", auth_views.LoginView.as_view(template_name="manage/login.html"), name="login"),
    path("manage/logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("manage/", admin_views.dashboard, name="manage_home"),
    path("manage/songs/", admin_views.songs, name="manage_songs"),
    path("manage/tips/", admin_views.tips, name="manage_tips"),
    path("manage/activities/", admin_views.activities, name="manage_activities"),
]
