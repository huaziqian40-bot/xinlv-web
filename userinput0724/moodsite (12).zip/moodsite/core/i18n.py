"""极简双语文案（中/英）。前端界面文案走这里；用户生成内容不翻译。"""

STRINGS = {
    "zh": {
        "nav_calendar": "心情日历", "nav_confidant": "AI 树洞", "nav_about": "关于我们",
        "nav_contribute": "我要分享", "login": "登录", "register": "注册", "logout": "退出",
        "my_home": "我的主页", "manage": "管理后台", "hello": "你好，",
        "view_month": "月", "view_week": "周", "view_year": "年",
        "hero_title": "今天，心情怎么样？",
        "hero_sub": "点一个日子，记录此刻的感受。我会陪你一起，看看能做点什么。",
        "recent_moods": "最近的心情", "record_mood": "记录心情",
        "save_and_see": "保存并看看建议", "cancel": "取消",
        "streak": "连续记录", "days": "天", "badges": "徽章", "total_records": "累计记录",
        "edit_profile": "编辑资料", "bio": "简介", "avatar": "头像", "save": "保存",
        "contribute_title": "分享给大家", "contribute_sub": "你的心理小知识、舒缓建议、音乐或视频，经审核后会加入网站。",
        "submit": "提交", "my_submissions": "我的投稿", "lang_name": "中文",
    },
    "en": {
        "nav_calendar": "Mood Calendar", "nav_confidant": "AI Tree Hole", "nav_about": "About",
        "nav_contribute": "Share", "login": "Log in", "register": "Sign up", "logout": "Log out",
        "my_home": "My Page", "manage": "Admin", "hello": "Hi, ",
        "view_month": "M", "view_week": "W", "view_year": "Y",
        "hero_title": "How are you feeling today?",
        "hero_sub": "Pick a day and note how you feel. I'll help you find something that helps.",
        "recent_moods": "Recent moods", "record_mood": "Record mood",
        "save_and_see": "Save & see suggestions", "cancel": "Cancel",
        "streak": "Streak", "days": "days", "badges": "Badges", "total_records": "Total records",
        "edit_profile": "Edit profile", "bio": "Bio", "avatar": "Avatar", "save": "Save",
        "contribute_title": "Share with others", "contribute_sub": "Your tips, activities, music or videos will join the site after review.",
        "submit": "Submit", "my_submissions": "My submissions", "lang_name": "English",
    },
}


def get_lang(request):
    if request.user.is_authenticated:
        try:
            l = request.user.profile.language
            if l in STRINGS:
                return l
        except Exception:
            pass
    return request.session.get("lang", "zh")


def i18n_context(request):
    lang = get_lang(request)
    return {"LANG": lang, "T": STRINGS[lang]}
