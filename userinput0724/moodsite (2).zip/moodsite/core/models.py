from django.conf import settings
from django.db import models
from django.db.models import Q


# ---- 心情定义 ----
# valence: 1 = 正面, 0 = 中性, -1 = 负面
MOODS = [
    ("happy",    "开心",  "😄", "#FFD56B",  1),
    ("calm",     "平静",  "🙂", "#9BD1C6",  1),
    ("excited",  "兴奋",  "🤩", "#FF9F68",  1),
    ("grateful", "感恩",  "🥰", "#F7A6C4",  1),
    ("tired",    "疲惫",  "😪", "#A6A6C9", -1),
    ("anxious",  "焦虑",  "😟", "#7FA6E8", -1),
    ("sad",      "难过",  "😢", "#6D8FB8", -1),
    ("angry",    "愤怒",  "😠", "#E8736B", -1),
    ("lonely",   "孤独",  "🌧️", "#8E94B8", -1),
    ("numb",     "麻木",  "😶", "#B0B0B0",  0),
]
MOOD_KEYS = [m[0] for m in MOODS]
MOOD_MAP = {m[0]: {"label": m[1], "emoji": m[2], "color": m[3], "valence": m[4]} for m in MOODS}


class MoodEntry(models.Model):
    """一条心情记录。
    登录用户：按 user 存（可跨设备同步）。
    未登录访客：不存这里，存在浏览器 localStorage。
    session_key 字段保留作历史兼容，新数据一般为空。
    """
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                             on_delete=models.CASCADE, related_name="moods")
    session_key = models.CharField(max_length=40, blank=True, default="", db_index=True)
    date = models.DateField(db_index=True)
    mood = models.CharField(max_length=20, choices=[(m[0], m[1]) for m in MOODS])
    note = models.TextField(blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-date"]
        constraints = [
            models.UniqueConstraint(fields=["user", "date"], condition=Q(user__isnull=False),
                                    name="uniq_user_date"),
        ]

    @property
    def info(self):
        return MOOD_MAP.get(self.mood, {})

    def __str__(self):
        return f"{self.date} {self.mood}"


class Song(models.Model):
    """本地音乐。文件放在 media/music/ 下，用 scan_music 命令自动导入。"""
    title = models.CharField(max_length=200)
    artist = models.CharField(max_length=200, blank=True, default="")
    audio = models.FileField(upload_to="music/")
    moods = models.CharField(max_length=200, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    def mood_list(self):
        return [m.strip() for m in self.moods.split(",") if m.strip()]

    def __str__(self):
        return f"{self.title} - {self.artist}" if self.artist else self.title


class Activity(models.Model):
    """舒缓行为 / 建议动作。"""
    text = models.CharField(max_length=300)
    moods = models.CharField(max_length=200, blank=True, default="")

    def mood_list(self):
        return [m.strip() for m in self.moods.split(",") if m.strip()]

    def __str__(self):
        return self.text


class PsychologyTip(models.Model):
    """心理学小知识，正面心情时推送。"""
    title = models.CharField(max_length=200)
    content = models.TextField()
    source = models.CharField(max_length=200, blank=True, default="")

    def __str__(self):
        return self.title


class ChatMessage(models.Model):
    """AI 树洞的对话记录。登录用户按 user 存，访客按 session 存。"""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                             on_delete=models.CASCADE, related_name="chats")
    session_key = models.CharField(max_length=40, blank=True, default="", db_index=True)
    role = models.CharField(max_length=12)  # user / assistant
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]


class SiteSettings(models.Model):
    """全站设置的单例：关于我们 + 联系方式 + 危机热线。pk 固定为 1。"""
    about_content = models.TextField(
        blank=True, default="# 关于我们\n\n在这里写点关于你和这个网站的故事吧。支持 **Markdown** 语法。",
        help_text="支持 Markdown",
    )
    contact_email = models.CharField(max_length=200, blank=True, default="")
    contact_phone = models.CharField(max_length=50, blank=True, default="")
    contact_wechat = models.CharField(max_length=100, blank=True, default="")
    crisis_hotline = models.CharField(max_length=100, blank=True, default="12356")
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "网站设置"

    def __str__(self):
        return "网站设置"

    @classmethod
    def load(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj
